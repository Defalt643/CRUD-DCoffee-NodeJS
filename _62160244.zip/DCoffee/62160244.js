const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');
const cors = require('cors');
var mysql = require('mysql')

let server = express();

server.use(bodyParser.json()); // ให้ server(express) ใช้งานการ parse json
server.use(morgan('dev')); // ให้ server(express) ใช้งานการ morgam module
server.use(cors()); // ให้ server(express) ใช้งานการ cors module
server.use(bodyParser.urlencoded({ extended: true }))// แปลงข้อมูลที่ส่งมาจากฟอร์ม
server.use(express.static('html'));
server.use(express.static('image'));


server.set('views', __dirname + '/public');// ระบุต าแหน่งของไฟล์ html
server.engine('html', require('ejs').renderFile);

let user = {}

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'dcoffee',
    password: '',
});

con.connect((err) => {
    if (err) {
        console.log('Error connecting to Db');
        return;
    }
    console.log('Connection established');
    });

server.get('/logout', function (req, res){
    const id = user.data.id_employee
   con.query('INSERT INTO trn_logout (id_employee, datetime_logout) VALUES (?, NOW())', id, function (err){
        if (err) return err;
    })
    res.render(__dirname + "/public/login.html")
});

server.post('/login', function(req, res){
    user = {}
    let email = req.body.email;
    let password = req.body.password;
    con.query('SELECT * FROM mst_security WHERE user = ?', [email], function(err, data){
        if(err) {
            console.log("err");
            return err;
        }if(data[0]==null){
            return res.sendFile(__dirname+'/public/nonmember.html')
        }
        if(password != data[0].password){
            console.log("Incorrect password");
            return res.redirect('/incorrectPassword')
        }
        if(data[0] == null){
            console.log('Error');
            return res.redirect('/')
        }
        con.query('SELECT * FROM mst_employee WHERE id_employee = ?', [data[0].id_employee],function(err,data2){
            console.log(data2);
            user = {
                data : data2[0]
            }
            res.redirect('/main')
        })
    })
});

server.get('/main', function (req, res) {
    const id = user.data.id_employee
    var lastid;
    con.query('SELECT * FROM trn_login',function(err,dataId){
        lastid=Object.values(JSON.parse(JSON.stringify(dataId))).length;
        console.log(lastid)
    });
    con.query('INSERT INTO trn_login (id_employee, datetime_login) VALUES (?, NOW())', id, function(err){
        if (err) return err;
    })
    res.render(__dirname + "/public/dashboard.html", {
        name: user.data.name,
        surname: user.data.surname,
        position: user.data.position
    })
})

server.get('/', function (req, res) {
    res.sendFile( __dirname+ "/public/" + "login.html");
});

server.get('/incorrectPassword',function(req,res){
    res.sendFile( __dirname+ "/public/" + "incorrectPassword.html");
})

server.listen(3000, function() {
    console.log('Server Listen at http://localhost:3000');
});
